const data = [
  {
    request: "pending",
    name: "ABC",
    prn: 12345678908,
    year: "1st Year",
    course: "B.Tech BioEng",
    note: ""
  },
  {
    request: "pending",
    name: "CIJK",
    prn: 12345678908,
    year: "1st Year",
    course: "B.Tech CSE",
    note: ""
  },
  {
    request: "pending",
    name: "KLM",
    prn: 12345678908,
    year: "1st Year",
    course: "MBA",
    note: ""
  },
  {
    request: "pending",
    name: "GHI",
    prn: 12345678908,
    year: "1st Year",
    course: "MBA",
    note: ""
  },
  {
    request: "accepted",
    name: "CDE",
    prn: 12345678908,
    year: "1st Year",
    course: "MBA",
    note: ""
  },
  {
    request: "accepted",
    name: "EFG",
    prn: 12345678908,
    year: "1st Year",
    course: "MBA",
    note: ""
  },
  {
    request: "accepted",
    name: "MNO",
    prn: 12345678908,
    year: "1st Year",
    course: "MBA",
    note: ""
  },
  {
    request: "accepted",
    name: "OPQ",
    prn: 12345678908,
    year: "1st Year",
    course: "MBA",
    note: ""
  },
  {
    request: "accepted",
    name: "QRS",
    prn: 12345678908,
    year: "1st Year",
    course: "MBA",
    note: ""
  }
];
export default data;
